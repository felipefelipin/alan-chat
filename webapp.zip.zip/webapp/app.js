const tg = window.Telegram?.WebApp;
if (tg) tg.ready();

const app = document.getElementById("app");

// assets
const ASSETS = {
  intro: "./assets/intro.mp4",
  callVideo: "./assets/call.mp4",
  audio1: "./assets/audio1.mp3",
  audio2: "./assets/audio2.mp3",
  ringtone: "./assets/ringtone.mp3"
};

const state = {
  chat: [],
  waiting: false,
  step: 0,
  audio: null,
  ring: null,
  camStream: null,
};

function nowTime() {
  const d = new Date();
  const hh = String(d.getHours()).padStart(2,'0');
  const mm = String(d.getMinutes()).padStart(2,'0');
  return `${hh}:${mm}`;
}

function mountIntro() {
  app.innerHTML = `
    <div class="full">
      <div class="videoWrap">
        <video id="introVid" playsinline muted autoplay src="${ASSETS.intro}"></video>
        <button id="goChat" class="overlayBtn" style="display:none;">IR PARA CONVERSA COM ALANA</button>
      </div>
    </div>
  `;

  const vid = document.getElementById("introVid");
  const btn = document.getElementById("goChat");

  // pausa em 5s e mostra botão
  const t = setInterval(() => {
    if (!vid.duration) return;
    if (vid.currentTime >= 5) {
      vid.pause();
      btn.style.display = "inline-block";
      clearInterval(t);
    }
  }, 120);

  btn.onclick = () => {
    // gesto do usuário libera áudio/vídeo depois
    mountChat();
    startScript();
  };
}

function mountChat() {
  app.innerHTML = `
    <div class="full">
      <div class="topbar">
        <div class="avatar">A</div>
        <div class="titlebox">
          <div class="name">Alana</div>
          <div class="status" id="status">online</div>
        </div>
      </div>

      <div class="chat" id="chat"></div>

      <div class="composer">
        <div class="wrap">
          <input id="input" placeholder="Mensagem..." autocomplete="off" />
          <button class="send" id="send">Enviar</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById("send").onclick = onSend;
  document.getElementById("input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") onSend();
  });

  state.chatEl = document.getElementById("chat");
}

function scrollBottom() {
  state.chatEl.scrollTop = state.chatEl.scrollHeight;
}

function addTyping() {
  const row = document.createElement("div");
  row.className = "row left";
  row.id = "typingRow";
  row.innerHTML = `
    <div class="typing">
      <div class="dot"></div><div class="dot"></div><div class="dot"></div>
    </div>
  `;
  state.chatEl.appendChild(row);
  scrollBottom();
}

function removeTyping() {
  const el = document.getElementById("typingRow");
  if (el) el.remove();
}

function addMsg(side, html) {
  const row = document.createElement("div");
  row.className = `row ${side}`;
  row.innerHTML = `
    <div class="bubble">
      ${html}
      <div class="meta">${nowTime()}</div>
    </div>
  `;
  state.chatEl.appendChild(row);
  scrollBottom();
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function typingDelayFor(text) {
  const len = String(text).length;
  const base = 500;
  const per = 22;
  const jitter = Math.floor(Math.random()*450);
  return Math.min(3800, base + len*per + jitter);
}

async function alanaSay(text, opts = {}) {
  addTyping();
  await sleep(opts.delay ?? typingDelayFor(text));
  removeTyping();
  addMsg("left", escapeHtml(text).replace(/\n/g, "<br/>"));
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;");
}

// --- Audio message bubble
function addAudio(side, src, durationLabel = "0:07") {
  const id = `aud_${Math.random().toString(16).slice(2)}`;

  const row = document.createElement("div");
  row.className = `row ${side}`;
  row.innerHTML = `
    <div class="bubble">
      <div class="audioChip" data-src="${src}" data-id="${id}">
        <div class="playBtn">▶</div>
        <div class="bar"><div class="fill" id="${id}"></div></div>
        <div style="font-size:12px;color:var(--muted)">${durationLabel}</div>
      </div>
      <div class="meta">${nowTime()}</div>
    </div>
  `;
  state.chatEl.appendChild(row);
  scrollBottom();

  row.querySelector(".audioChip").onclick = async (e) => {
    const chip = e.currentTarget;
    await playAudioChip(chip);
  };
}

async function playAudioChip(chip) {
  const src = chip.dataset.src;
  const fillId = chip.dataset.id;
  const fill = document.getElementById(fillId);

  // stop previous
  if (state.audio) {
    state.audio.pause();
    state.audio = null;
  }

  const audio = new Audio(src);
  state.audio = audio;

  // autoplay may fail without user gesture — but user clicked chip, ok
  audio.play().catch(() => {});

  const start = Date.now();
  const tick = setInterval(() => {
    if (!audio || audio.paused) {
      clearInterval(tick);
      if (fill) fill.style.width = "0%";
      return;
    }
    const p = Math.min(1, audio.currentTime / (audio.duration || 1));
    if (fill) fill.style.width = `${Math.floor(p*100)}%`;
  }, 80);

  audio.onended = () => {
    clearInterval(tick);
    if (fill) fill.style.width = "0%";
  };
}

// --- User sending
function onSend() {
  const input = document.getElementById("input");
  const text = input.value.trim();
  if (!text) return;

  input.value = "";
  addMsg("right", escapeHtml(text));
  handleUserText(text);
}

// --------------------
// Script logic (state machine)
// --------------------
async function startScript() {
  state.step = 0;

  await alanaSay("você entrou mesmo…");
  await sleep(700);
  await alanaSay("achei que você só ia olhar e sair");

  await sleep(900);
  await alanaSay("me responde uma coisa rápido…");
  await sleep(350);
  await alanaSay("você gosta de ir até o fim…\nou prefere ir com calma?");

  state.step = 1; // wait first user answer
}

async function handleUserText(text) {
  // step 1: first answer
  if (state.step === 1) {
    state.step = 2;

    await alanaSay("ok…");
    await sleep(700);
    await alanaSay("então presta atenção agora");

    // audio 1
    await sleep(800);
    await alanaSay("vou te mandar uma coisa rapidinho…");
    await sleep(500);
    addAudio("left", ASSETS.audio1, "0:07");

    await sleep(900);
    await alanaSay("e não some no meio, tá?");

    await sleep(1100);
    await alanaSay("se eu abrir mais… você promete que não vai parar no meio?");
    state.step = 3; // wait promise
    return;
  }

  // step 3: promise answer
  if (state.step === 3) {
    state.step = 4;

    await alanaSay("…tá.");
    await sleep(650);
    await alanaSay("então olha isso");

    // audio 2 (logo antes do “pedido de chamada”)
    await sleep(800);
    await alanaSay("mas antes… escuta.");
    await sleep(450);
    addAudio("left", ASSETS.audio2, "0:06");

    await sleep(1100);
    await alanaSay("posso te mostrar uma coisa por chamada rapidinho?");
    state.step = 5; // wait yes/no (free text)
    return;
  }

  // step 5: after “call” consent -> trigger call regardless, but react to text
  if (state.step === 5) {
    state.step = 6;

    await alanaSay("ok… espera.");
    await sleep(650);
    await alanaSay("não some.");

    // incoming call after short delay
    await sleep(900);
    showIncomingCall();
    return;
  }
}

// --------------------
// Call simulation
// --------------------
function showIncomingCall() {
  // ringtone (optional)
  try {
    state.ring = new Audio(ASSETS.ringtone);
    state.ring.loop = true;
    state.ring.play().catch(() => {});
  } catch {}

  app.insertAdjacentHTML("beforeend", `
    <div class="callScreen" id="callScreen">
      <div class="callHeader">
        <div class="avatar">A</div>
        <div>
          <div class="callName">Alana</div>
          <div class="callSub" id="callSub">chamada de vídeo…</div>
        </div>
      </div>

      <div class="callBody">
        <div class="selfCam" id="selfCam" style="display:none;">
          <video id="selfVideo" autoplay playsinline muted></video>
        </div>

        <div style="text-align:center;">
          <div style="font-size:14px;color:var(--muted)">tocando…</div>
        </div>
      </div>

      <div class="callActions">
        <button class="btnRed" id="decline">Recusar</button>
        <button class="btnGreen" id="accept">Atender</button>
      </div>
    </div>
  `);

  document.getElementById("decline").onclick = () => endCall(false);
  document.getElementById("accept").onclick = () => acceptCall();
}

async function acceptCall() {
  // stop ringtone
  if (state.ring) {
    state.ring.pause();
    state.ring = null;
  }

  // try start self camera preview (permission required)
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    state.camStream = stream;

    const selfCam = document.getElementById("selfCam");
    const selfVideo = document.getElementById("selfVideo");
    selfCam.style.display = "block";
    selfVideo.srcObject = stream;
  } catch {
    // permission denied -> just continue without self preview
  }

  // show her video for 5s then drop
  const call = document.getElementById("callScreen");
  call.querySelector(".callBody").innerHTML = `
    <div class="videoWrap">
      <video id="callVid" playsinline autoplay src="${ASSETS.callVideo}"></video>
      <div class="selfCam" id="selfCam2" style="display:${state.camStream ? "block" : "none"};">
        <video id="selfVideo2" autoplay playsinline muted></video>
      </div>
    </div>
  `;

  if (state.camStream) {
    const v2 = document.getElementById("selfVideo2");
    v2.srcObject = state.camStream;
  }

  const vid = document.getElementById("callVid");
  // guarantee stop at 5s even if video longer
  const t = setInterval(() => {
    if (vid.currentTime >= 5) {
      clearInterval(t);
      endCall(true);
    }
  }, 100);

  // if video ends before 5s, end call
  vid.onended = () => {
    clearInterval(t);
    endCall(true);
  };
}

async function endCall(wasAnswered) {
  // stop ringtone
  if (state.ring) {
    state.ring.pause();
    state.ring = null;
  }

  // stop camera
  if (state.camStream) {
    state.camStream.getTracks().forEach(t => t.stop());
    state.camStream = null;
  }

  const call = document.getElementById("callScreen");
  if (call) call.remove();

  // back to chat — keep flow moving
  if (!state.chatEl) return;

  if (!wasAnswered) {
    await alanaSay("…ok.");
    await sleep(700);
    await alanaSay("eu te mostro do outro jeito então.");
  } else {
    await alanaSay("…caiu.");
    await sleep(750);
    await alanaSay("isso foi só um pedaço.");
  }

  await sleep(900);
  await alanaSay("o resto eu não deixo aberto assim.");
  await sleep(700);
  await alanaSay("se você quiser continuar… eu destravo no acesso.");

  await sleep(800);
  showUnlock();
}

function showUnlock() {
  // botão final (aqui pode ser só 1)
  const card = document.createElement("div");
  card.className = "card";
  card.style.margin = "14px auto 0";
  card.innerHTML = `
    <div style="font-weight:900;font-size:16px;margin-bottom:10px;">conteúdo bloqueado</div>
    <div style="color:var(--muted);margin-bottom:14px;">
      desbloqueie pra continuar de onde parou.
    </div>
    <button id="unlock" style="width:100%;background:var(--accent);color:#062213;">
      desbloquear acesso
    </button>
  `;
  state.chatEl.appendChild(card);
  scrollBottom();

  document.getElementById("unlock").onclick = () => {
    // envia pro bot iniciar checkout
    if (tg) tg.sendData(JSON.stringify({ action: "checkout" }));
    if (tg) tg.close();
  };
}

// init
mountIntro();